import React from "react";
import { useHistory } from "react-router-dom";
import "../styles/Drawer.css";

const Drawer = () => {
  const history = useHistory();
  return (
    <div className="drawerContainer">
      <div className="headerDrawer">اگه دنبال کد تخفیف ۵ درصدی هستی<br></br>
      😉👇 تو کمد دنبالش بگرد
      </div>
      <div className="chest">
        <div className="chest__panel chest__panel--back"></div>
        <div className="chest__panel chest__panel--front">
          <div className="chest__panel chest__panel--front-frame"></div>
        </div>
        <div className="chest__panel chest__panel--top"></div>
        <div className="chest__panel chest__panel--bottom"></div>
        <div className="chest__panel chest__panel--left"></div>
        <div className="chest__panel chest__panel--right"></div>
        <div className="chest-drawer chest-drawer--top">
          <details>
            <summary></summary>
          </details>
          <div className="chest-drawer__structure">
            <div className="chest-drawer__panel chest-drawer__panel--left"></div>
            <div className="chest-drawer__panel chest-drawer__panel--right"></div>
            <div className="chest-drawer__panel chest-drawer__panel--bottom"></div>
            <div className="chest-drawer__panel chest-drawer__panel--back fontR">پوچ 😀</div>
          </div>
        </div>
        <div className="chest-drawer chest-drawer--middle">
          <details>
            <summary></summary>
          </details>
          <div className="chest-drawer__structure">
            <div className="chest-drawer__panel chest-drawer__panel--left"></div>
            <div className="chest-drawer__panel chest-drawer__panel--right"></div>
            <div className="chest-drawer__panel chest-drawer__panel--bottom"></div>
            <div className="chest-drawer__panel chest-drawer__panel--back fontR"> 😀 پوچ</div>
          </div>
        </div>
        <div className="chest-drawer chest-drawer--bottom">
          <details>
            <summary></summary>
          </details>
          <div className="chest-drawer__structure">
            <div className="chest-drawer__panel chest-drawer__panel--left"></div>
            <div className="chest-drawer__panel chest-drawer__panel--right"></div>
            <div className="chest-drawer__panel chest-drawer__panel--bottom"></div>
            <div className="chest-drawer__panel chest-drawer__panel--back">
              YALDA02
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Drawer;

// URl : https://codepen.io/jh3y/pen/mLaXRe
