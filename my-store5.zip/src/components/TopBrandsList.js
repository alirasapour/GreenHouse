
import React from 'react'
import { useHistory } from 'react-router-dom'
import "../styles/TopBrandsList.css"
import img1 from "../images/mi.png"
import img2 from "../images/anker.png"
import img3 from "../images/baseus.png"
import img4 from "../images/tdagger.png"
import img5 from "../images/adata.png"
import img6 from "../images/mcdodo.png"
import img7 from "../images/lenovo.png"
import img8 from "../images/razer.png"

const TopBrandsList = () => {
    const history = useHistory()
    return (
        <div className="TopBrandsListContainer">
            <p className="BrandTitleStyle">برترین برند ها</p>
            <div className="slider">
                <div className="slide-track">
                    <div className="slide">
                        <img src={img1} height="100" width="250" alt="" />
                    </div>
                    <div className="slide">
                        <img src={img2} height="100" width="250" alt="" />
                    </div>
                    <div className="slide">
                        <img src={img3} height="100" width="250" alt="" />
                    </div>
                    <div className="slide">
                        <img src={img4} height="100" width="250" alt="" />
                    </div>
                    <div className="slide">
                        <img src={img5} height="100" width="250" alt="" />
                    </div>
                    <div className="slide">
                        <img src={img6} height="100" width="250" alt="" />
                    </div>
                    <div className="slide">
                        <img src={img7} height="100" width="250" alt="" />
                    </div>
                    <div className="slide">
                        <img src={img8} height="100" width="250" alt="" />
                    </div>
                </div>
            </div>
        </div>

    )
}

export default TopBrandsList


// URl : https://codepen.io/studiojvla/pen/qVbQqW