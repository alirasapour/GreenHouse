
import React from 'react'
import '../styles/Slider.css'

const Slider = () => {
    return (
        <div className="sliderContainerE" >
            {/* Content */}
            <figure className="icon-cards mt-3">
                <div className="icon-cards__content">
                    <div className="icon-cards__item d-flex align-items-center justify-content-center"><img className="imagesliderE" src="https://www.lioncomputer.com/uploads/image/2022/7/1658577390-ih1N3SKumwAUlah0.webp"/></div>
                    <div className="icon-cards__item d-flex align-items-center justify-content-center"><img className="imagesliderE" src="https://www.lioncomputer.com/uploads/image/2022/7/1658647630-k5UQngmzQDxjD70C.webp"/></div>
                    <div className="icon-cards__item d-flex align-items-center justify-content-center"><img className="imagesliderE" src="https://www.lioncomputer.com/uploads/image/2022/7/1658577222-bwdHf77CBQmD2row.webp"/></div>
                </div>
            </figure>
            {/* Content */}
            {/* <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.0.0/css/bootstrap.cs"/> */}
        </div>
    )
}

export default Slider;



// zoom level Problem