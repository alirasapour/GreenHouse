import React from "react";
import "../styles/TakProduct.css";
import ProductImage from "../images/espreso.png";
import { useHistory } from "react-router-dom";

const TakProduct = () => {
  const history = useHistory()
  return (
    <div style={{ marginTop: 55}}>
      <p className="BrandTitleStyle" style={{ textAlign: "end" }}>
        محصول جدید فروشگاه ما رو دیدی ؟
      </p>
      <div className="containerTKEE">
        <div className="TPcontainer">
          <div className="TPimgBx">
            <img src={ProductImage} alt="" />
          </div>
          <div className="TPdetails">
            <div>
              <h2>
                قهوه‌ساز کپسولی قابل حمل شیائومی <br></br>
                <span>Xiaomi Mijia Coffee Machine Scishare S1106</span>
              </h2>
              <p className="fontR">
                سبک و مینیمال<br></br>
                دارای دو میزان حجم قهوه‌گیری<br></br>
                خاموشی خودکار<br></br>
                فن آوری گرمایش سریع و سیستم استخراج پایدار<br></br>
                مخزن آب 450 میلی‌لیتری جداشدنی
              </p>
              <h3 dir="rtl">4,650 تومان</h3>
              <button onClick={() => history.push('/product/23')}>مشاهده و خرید</button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default TakProduct;

// URL : https://codepen.io/anuzbvbmaniac/pen/QWWoPxj
