import React from 'react'
import { useHistory } from 'react-router-dom'
import "../styles/Categories.css"
import cat1 from "../images/category/cat1.png"
import cat2 from "../images/category/cat2.png"
import cat3 from "../images/category/cat3.png"
import cat4 from "../images/category/cat4.png"
import cat5 from "../images/category/cat5.png"
import cat6 from "../images/category/cat6.png"
import cat7 from "../images/category/cat7.png"
import cat8 from "../images/category/cat8.png"
import cat9 from "../images/category/cat9.png"
import cat10 from "../images/category/cat10.png"
import cat11 from "../images/category/cat11.png"

const marginfromTop = 55

const Categories = () => {
    const history = useHistory()
    return (
        <div>
            <p className="BrandTitleStyle" style={{ textAlign: 'right' }}>دسته بندی ها</p>
            <div className="CatgoriesItemsListView">
                <div className="CategoriesItemsListE" style={{marginTop : 8}}>
                    <img className="CategoriesImgStyleE" src={cat1} />
                    <p style={{ margin: 0, fontFamily: "FBold", fontSize: 13 }}>کالای دیجیتال</p>
                </div>
                <div className="CategoriesItemsListE" style={{marginTop : 8}}>
                    <img className="CategoriesImgStyleE" src={cat2} />
                    <p style={{ margin: 0, fontFamily: "FBold", fontSize: 13 ,textAlign : 'center'}}>موبایل</p>
                </div>
                <div className="CategoriesItemsListE" style={{marginTop : 8}} >
                    <img className="CategoriesImgStyleE" src={cat3} />
                    <p style={{ margin: 0, fontFamily: "FBold", fontSize: 13 }}>خودرو، ابزار و تجهیزات صنعتی</p>
                </div>
                <div className="CategoriesItemsListE" style={{marginTop : marginfromTop}}>
                    <img className="CategoriesImgStyleE" src={cat4} />
                    <p style={{ margin: 0, fontFamily: "FBold", fontSize: 13 }}>مد و پوشاک</p>
                </div>
                <div className="CategoriesItemsListE" style={{marginTop : marginfromTop}}>
                    <img className="CategoriesImgStyleE" src={cat5} />
                    <p style={{ margin: 0, fontFamily: "FBold", fontSize: 13 }}>کالاهای سوپرمارکتی</p>
                </div>
                <div className="CategoriesItemsListE" style={{marginTop : marginfromTop}}>
                    <img className="CategoriesImgStyleE" src={cat6} />
                    <p style={{ margin: 0, fontFamily: "FBold", fontSize: 13 }}>اسباب بازی، کودک و نوزاد</p>
                </div>
                <div className="CategoriesItemsListE" style={{marginTop : marginfromTop}}>
                    <img className="CategoriesImgStyleE" src={cat7} />
                    <p style={{ margin: 0, fontFamily: "FBold", fontSize: 13 }}>محصولات بومی و محلی</p>
                </div>
                <div className="CategoriesItemsListE" style={{marginTop : marginfromTop}}>
                    <img className="CategoriesImgStyleE" src={cat8} />
                    <p style={{ margin: 0, fontFamily: "FBold", fontSize: 13 }}>زیبایی و سلامت</p>
                </div>
                <div className="CategoriesItemsListE" style={{marginTop : marginfromTop}}>
                    <img className="CategoriesImgStyleE" src={cat9} />
                    <p style={{ margin: 0, fontFamily: "FBold", fontSize: 13 }}>خانه و آشپزخانه</p>
                </div>
                <div className="CategoriesItemsListE" style={{marginTop : marginfromTop}}>
                    <img className="CategoriesImgStyleE" src={cat10} />
                    <p style={{ margin: 0, fontFamily: "FBold", fontSize: 13 }}>کتاب، لوازم تحریر و هنر</p>
                </div>
                <div className="CategoriesItemsListE" style={{marginTop : marginfromTop}}>
                    <img className="CategoriesImgStyleE" src={cat11} />
                    <p style={{ margin: 0, fontFamily: "FBold", fontSize: 13 }}>ورزش و سفر</p>
                </div>
                <div className="CategoriesItemsListE" style={{marginTop : marginfromTop}}>
                    <img className="CategoriesImgStyleE" src={cat1} />
                    <p style={{ margin: 0, fontFamily: "FBold", fontSize: 13 }}>کالای دیجیتال</p>
                </div>
            </div>
        </div>

    )
}

export default Categories


// URl : https://codepen.io/zitrusfrisch/pen/kBNEag