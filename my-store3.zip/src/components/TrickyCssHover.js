import React from 'react'
import { useHistory } from 'react-router-dom'
import "../styles/TrickyCssHover.css"
import ProductImage from '../images/MI-wifi-repeater2.png';

const TrickyCssHover = () => {
    const history = useHistory()
    return (
        <div>
            <div className="wrapper">
                <div className="card">
                    <div className="front">
                        <h1 className="TCHh1">تقویت کننده وای فای</h1>
                        <p className="TCHp">Xiaomi<span className="TCHspan">تولید 2022</span></p>
                        <p className="TCHprice">مدل WiFi Amplifier 2</p>
                    </div>
                    <div className="TCHright">
                        <h2 className="TCHh2">مشخصات</h2>
                        <ul className="TCHul">
                            <li>گارانتی اصالت و سلامت فیزیکی 7 روز مهلت تست</li>
                            <li>قابلیت چرخش با زاویه ۱۸۰ درجه</li>
                            <li>دارای منبع تغذیه با پورت USB</li>
                            <li>وزن محصول با بسته بندی : 60 گرم</li>
                        </ul>
                        <button onClick={() => alert("CLICKED")} className="TCHbuttun">مشاهده ، آموزش و خرید</button>
                    </div>
                </div>
                <div className="TCHimg-wrapper">
                    {/* // add new style to img style */}
                    <img className='imgProductAnimation'  src={ProductImage} alt='' />
                </div>
            </div>






        </div>
    )
}

export default TrickyCssHover