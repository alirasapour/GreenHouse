import React from 'react'
import BottomNavBar from '../components/BottomNavBar'
import searchIcon from '../images/search.jpg'
const titleNL = {
    paddingRight: 20,
    fontSize: 22
}

const Search = () => {
    return (
        <div >
            <div>
                <div style={{ display: 'flex', backgroundImage: `url(${searchIcon})`, backgroundSize: ['100%', '100%'], width: '100vw', height: '67.11vw' }}>
                    sdsd
                </div>
                <h1 dir="rtl" style={titleNL}>جستجو</h1>
            </div>
            <BottomNavBar name='search' />
        </div>
    )
}

export default Search

