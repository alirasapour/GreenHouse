import React from "react";
import BottomNavBar from "../components/BottomNavBar";
import { useHistory } from "react-router-dom";
import TrickyCssHover from "../components/TrickyCssHover";
import CssTextAnimation from "../components/CssTextAnimation";
import OpeningSequence from "../components/OpeningSequence";
import Row4 from "../components/Rows4";
import Drawer from "../components/Drawer";
import Whatsapp from "../images/whatsapp.png";
import NavDrawer from "../components/NavDrawer";
import Slider from "../components/Slider";
import TopBrandsList from "../components/TopBrandsList";
import Categories from "../components/Categories";
import TakProduct from "../components/TakProduct";
// import Loader from "../components/Loader";


export default class Home extends React.Component {
  constructor() {
    super();
    this.state = { isLoading : true};
  }


  componentDidMount() {
    // setTimeout(() => {
    //   this.setState({isLoading : false})
    // }, 3200);
  }

  render() {
    return (
      <div>
        {/* {this.state.isLoading == true ? <Loader /> : null} */}
        {/* Header */}
        <div className="fixed-top">
          <NavDrawer />
          <CssTextAnimation />
          <img src={Whatsapp} className="menu-nav-icon" alt="" />
        </div>
        {/* Header */}
        {/* Content */}
        <div className="content">
          <Slider />
          <TrickyCssHover />
          <Row4 />
          <Categories />
          <TakProduct />
          <TopBrandsList />
          <Drawer />
          <div style={{marginTop : 90}}></div>
          {/* <OpeningSequence /> */}
          {/* <p onClick={()=> this.props.history.push("/sdsd")}>sd</p> */}
        </div>
        {/* Content */}

        <BottomNavBar name="home" />
      </div>
    );
  }
}
