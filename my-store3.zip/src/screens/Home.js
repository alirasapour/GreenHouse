import React from "react";
import BottomNavBar from "../components/BottomNavBar";
import { useHistory } from "react-router-dom";
import TrickyCssHover from "../components/TrickyCssHover";
import CssTextAnimation from "../components/CssTextAnimation";
import OpeningSequence from "../components/OpeningSequence";
import Row4 from "../components/Rows4";
import Drawer from "../components/Drawer";
import Whatsapp from "../images/whatsapp.png";
import NavDrawer from "../components/NavDrawer";
import Slider from "../components/Slider";

const Home = () => {
  const history = useHistory();
  return (
    <div>
      {/* Header */}
      <div className="fixed-top">
      <NavDrawer/>
        <CssTextAnimation />
        <img src={Whatsapp} className="menu-nav-icon" alt="" />
      </div>

      {/* Header */}
      {/* Content */}
      <div className="content">
        <Slider/>
        <TrickyCssHover />
        <Row4 />
        <Drawer />
        <OpeningSequence />
      </div>
      {/* Content */}
     
      <BottomNavBar name="home" />
    </div>
  );
};

export default Home;

// onClick={() => history.push('/search')}
