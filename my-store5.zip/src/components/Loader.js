import React from "react";
import { useHistory } from "react-router-dom";

import Lottie from "lottie-react";
import LoaderAnimation from "../animation/loader.json";
const Loader = () => {
  const history = useHistory();
  return (
    <div
      style={{
        display: "flex",
        backgroundColor: "white",
        height: "100%",
        position: "fixed",
        width: "100vw",
        zIndex: 999,
        alignItems: "center",
        justifyContent: "center",
        flexDirection: 'column'
      }}
    >
      <Lottie animationData={LoaderAnimation} />
      <p style={{ fontFamily: 'FBold', fontSize: 19, marginTop: -25, zIndex: 1 }} dir="rtl">در حال بارگزاری ...</p>
    </div>
  );
};

export default Loader;
