import React from 'react'
import { useParams } from 'react-router-dom'
import infoimgTag from '../images/info.png'
import img1 from "../images/product/p1.jpg"
import img2 from "../images/product/p2.jpg"
import img3 from "../images/product/p3.jpg"
import img4 from "../images/product/p4.jpg"

const TitleFarsi = {
    color: 'black',
    fontFamily: 'FBold',
    fontSize: 19,
    margin: 0
}

const TitleEnglisi = {
    color: 'gray',
    fontFamily: 'FBold',
    fontSize: 16,
    margin: 0
}

const ProDuctContainerStyle = {
    padding: 30,
}

const ProductRowsInfoContainer = {
    display: 'flex',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'flex-start',
}

const ProductRowsInfoIMGContainer = {
    width: 25,
    height: 25,
    marginLeft: 5
}

const ProductRowsInfoTitlteContainer = {

}

const Product = () => {

    const { id } = useParams()
    return (
        <div dir="rtl" style={ProDuctContainerStyle}>
            <h1 style={TitleFarsi}>قهوه‌ساز کپسولی قابل حمل شیائومی</h1>
            <h3 style={TitleEnglisi}>Xiaomi Mijia Coffee Machine Scishare S1106</h3>
            <div class="PSscroll-container">
                <div class="PSgridscroll">
                    <img src={img1} />
                    <img src={img2} />
                    <img src={img3} />
                    <img src={img4} />
                </div>
            </div>
            <div style={ProductRowsInfoContainer}>
                <img src={infoimgTag} style={ProductRowsInfoIMGContainer} />
                <h4 style={ProductRowsInfoTitlteContainer}>ویژگی ها</h4>
            </div>
            <p className="fontR" style={{ marginTop: -10 }}>
                سبک و مینیمال<br></br>
                دارای دو میزان حجم قهوه‌گیری<br></br>
                خاموشی خودکار<br></br>
                فن آوری گرمایش سریع و سیستم استخراج پایدار<br></br>
                مخزن آب 450 میلی‌لیتری جداشدنی
            </p>
            {/* {id} */}
        </div>
    )
}

export default Product

// url : https://codepen.io/adityajanuardi/pen/YzydaVj
// url : https://codepen.io/jkantner/pen/eYMBNpv
// url : https://www.hitel.ir/product/scishare-s1106/#