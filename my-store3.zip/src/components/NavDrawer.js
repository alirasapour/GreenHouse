import React from 'react'
import '../styles/NavDrawer.css'
import MenuIcon from "../images/menu.png";

const NavDrawer = () => {
    return (
        <div>
            {/* Content */}

            <label for="menu-opener" tabindex="0" aria-haspopup="true" role="button" aria-controls="menu" id="openmenu"><img src={MenuIcon} className="menu-nav-icon" alt="" /></label>
            <input type="checkbox" data-menu id="menu-opener" hidden />
            <aside className="DrawerMenu" role="menu" id="menu" aria-labelledby="openmenu">
                <nav className="Menu">
                    <h2>Awesome CSS Menu</h2>
                    <a role="menuitem" tabindex="-1" href="#">Menu Item 01</a>
                    <a role="menuitem" tabindex="-1" href="#">Menu Item 02</a>
                    <a role="menuitem" tabindex="-1" href="#">Menu Item 03</a>
                    <a role="menuitem" tabindex="-1" href="#">Menu Item 04</a>
                    <a role="menuitem" tabindex="-1" href="#">Menu Item 05</a>
                    <a role="menuitem" tabindex="-1" href="#">Menu Item 06</a>
                    <a role="menuitem" tabindex="-1" href="#">Menu Item 07</a>
                    <a role="menuitem" tabindex="-1" href="#">Menu Item 08</a>
                    <a role="menuitem" tabindex="-1" href="#">Menu Item 09</a>
                    <a role="menuitem" tabindex="-1" href="#">Menu Item 10</a>
                    <a role="menuitem" tabindex="-1" href="#">Menu Item 11</a>
                    <a role="menuitem" tabindex="-1" href="#">Menu Item 12</a>
                    <a role="menuitem" tabindex="-1" href="#">Menu Item 13</a>
                    <a role="menuitem" tabindex="-1" href="#">Menu Item 14</a>
                    <a role="menuitem" tabindex="-1" href="#">Menu Item 15</a>
                </nav>
                <label for="menu-opener" className="MenuOverlay"></label>
            </aside>
            {/* Content */}
        </div>
    )
}

export default NavDrawer