import React from 'react'
import BottomNavBar from '../components/BottomNavBar'
import bellIcon from '../images/bell.jpg'
const titleNL = {
    paddingRight: 20,
    fontSize: 22
}
const titleNLL = {
    paddingRight: 20,
    fontSize: 18,
    fontFamily: 'FBold'
}

const inputNLL = {
    width: '88%',
    height: 45,
    textAlign: 'center',
    borderRadius: 5,
    borderColor: 'black',
    fontFamily: 'FBold',
    letterSpacing: 1,
    fontSize : 18
}
const NLinputContainerNL = {
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
}
const Favourites = () => {
    return (
        <div >
            <div>
                <img style={{ width: "100%", }} src={bellIcon} />
                <h1 dir="rtl" style={titleNL}>خبرنامه</h1>
                <h4 dir="rtl" style={titleNLL}>با اشتراک در خبرنامه و اطلاع رسانی سایت ما می توانید از <span style={{ color: '#2ac8dd' }}>تخفیفات</span> و <span style={{ color: "blue" }}>محصولات جدید</span> سریع تر از بقیه مطلع شوید.</h4>
                <div style={NLinputContainerNL}>
                    <input style={inputNLL} type="tel" id="phone" name="phone" placeholder="مثال : 09121234567" />
                </div>
            </div>
            <BottomNavBar name='favourites' />
        </div>
    )
}

export default Favourites


// url : https://codepen.io/nourabusoud/pen/ypZzMM