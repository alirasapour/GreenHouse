import React from 'react'
import { useEffect } from 'react';
import BottomNavBar from '../components/BottomNavBar'
import "../styles/AccountScreenStyle.css";

const Account = () => {
    useEffect(() => {
        const script = document.createElement('script');
        script.src = "/js/AccountScreen.js";
        script.async = true;
        document.body.appendChild(script);
      return () => {
          document.body.removeChild(script);
        }
      }, []);


    return (
        <div className="loginContainerE">
            <div className="form-structor">
                <div className="signup">
                    <h2 className="form-title" id="signup">ثبت نام</h2>
                    <div className="form-holder">
                        <input type="text" className="input" placeholder="نام و نام خانوادگی" />
                        <input type="tel" className="input"  placeholder="شماره موبایل" />
                        <input type="password" className="input" placeholder="رمز عبور" />
                    </div>
                    <button className="submit-btn">تکمیل ثبت نام</button>
                </div>
                <div className="login slide-up">
                    <div className="center">
                        <h2 className="form-title" id="login"><span style={{marginLeft : '10px'}}>یا</span>ورود</h2>
                        <div className="form-holder">
                            <input type="email" className="input" placeholder="شماره تلفن" />
                        </div>
                        <button className="submit-btn">ورود</button>
                    </div>
                </div>
            </div>
            <script>

            </script>
            {/* Accout Page */}
            <BottomNavBar name='account' />
        </div>
    )
}

export default Account