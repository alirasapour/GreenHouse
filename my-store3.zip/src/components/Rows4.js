import React from "react";
import { useHistory } from "react-router-dom";
import "../styles/Row4.css";
import Banner1 from "../images/b1.png";
import Banner2 from "../images/b2.png";
import Banner3 from "../images/b3.png";
import Banner4 from "../images/b4.png";
const Row4 = () => {

  const history = useHistory();
  return (
    <div className="row4">
      <a href="">
        <img className="imgBanner" src={Banner1} alt="" />
      </a>
      <a href="">
        <img className="imgBanner" src={Banner2} alt="" />
      </a>
      <a href="">
        <img className="imgBanner" src={Banner3} alt="" />
      </a>
      <a href="">
        <img className="imgBanner" src={Banner4} alt="" />
      </a>
    </div>
  );
};

export default Row4;
