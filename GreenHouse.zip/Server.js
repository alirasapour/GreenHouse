console.clear();
const express = require('express');
const app = express()
const port = 4500
const open = require('open');
app.set('view engine', 'ejs');
app.use(express.static(__dirname + '/public'));
let line1400 = {
	Status: 'نامشخص',
	Tolid: 12500,
	Speed: 23,
	Status : 1,
	FunctionRS : 2
}

setTimeout(async () => {
	await open('http://localhost:4500', { app: { name: 'firefox' } });
}, 2000);

app.get('/', (req, res) => {
	res.render('./dashboard.ejs')
})

app.get('/14000', (req, res) => {
	res.render('./gol1.ejs')
})


app.get('/14000data', (req, res) => {
	res.json(line1400)
})

app.get('/14000data/getPLCFunction', (req, res) => {
	let func = line1400.FunctionRS;
	line1400.FunctionRS = 2
	res.json(func)
})

app.get('/14000data/setSpeed', (req, res) => {
	// line1400.Speed = req.query.Speed
	res.send('1')
})

app.get('/14000data/getSpeedLine', (req, res) => {
	res.json(line1400)
})

app.get('/14000data/setFromPLC', (req, res) => {
	line1400.Tolid = req.query.Tolid
	line1400.Speed = req.query.Speed
	res.send('1')
})


app.get('/home', (req, res) => {
	res.render('./index.ejs')
})


app.listen(port, () => {
	console.log(`GreenHouse -FTM webApplication listening on port ${port}`)
})
