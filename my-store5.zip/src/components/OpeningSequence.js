
import React from 'react'
import { useHistory } from 'react-router-dom'
import "../styles/OpeningSequence.css"


const OpeningSequenceAnimation = () => {
    const history = useHistory()
    return (
        <p className="TextEffectOne">با ما بروز باشید.<br></br><a href="" className="TextEffectOneaTag" >دریافت کد تخفیف ۵ درصدی</a></p>

    )
}

export default OpeningSequenceAnimation


// URl : https://codepen.io/grohit/pen/mdJqEzK