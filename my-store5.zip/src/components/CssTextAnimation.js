
import React from 'react'
import { useHistory } from 'react-router-dom'
import "../styles/CssTextAnimation.css"


const CssTextAnimation = () => {
    const history = useHistory()
    return (
        <h1 className="text-effect-css">فروشگاه اینترنتی ۷۲۰</h1>

    )
}

export default CssTextAnimation


// URl : https://codepen.io/zitrusfrisch/pen/kBNEag